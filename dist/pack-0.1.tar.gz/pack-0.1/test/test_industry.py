from data.databasemgr import DatabaseMgr
from data.storemgr import StockMgr

StockMgr.instance().getIndustryStocks('传媒')


