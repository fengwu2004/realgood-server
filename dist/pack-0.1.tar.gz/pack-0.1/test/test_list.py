mylist = [21, 22, 23, 24, 25]

with max(mylist[10:10]) as a:

    print(a)

print('ok')